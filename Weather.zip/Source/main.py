############################################
# TITLE  # WEATHER APP
# AUTHOR # DR NEIL ELIOT
# DATE   # 08/01/2023
############################################
# NOTES
###################################################################################
# BEWARE ONLY USE THE INTERNAL DHT11 LIBRARY OR IT FREEZES
###################################################################################
# NE - 22/02/2023
# REMOVED BUZZER
###################################################################################

from machine import Pin, Timer
import ssd1306
from oled import Write, GFX, SSD1306_I2C
from oled.fonts import ubuntu_mono_12, ubuntu_mono_15, ubuntu_mono_20
from dht import DHT11
import framebuf
import time
import random

reset = Pin(15,Pin.OUT)
sensor = DHT11(Pin(7))
led = Pin(25,Pin.OUT)
i2c = machine.I2C(0,sda=Pin(16), scl=Pin(17), freq=400000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)
gfx = GFX(128, 64, oled.pixel)
write12 = Write(oled, ubuntu_mono_12)
write15 = Write(oled, ubuntu_mono_15)
write20 = Write(oled, ubuntu_mono_20)

prevTemp = 0
prevHumi = 0

def resetcallback(reset):
    reset.irq(handler=None)
    oled.fill(0)
    oled.text("SYSTEM RESET",18,20)                             # TITLE DISPLAY
    oled.show()
    time.sleep(5)
    machine.reset()

def arrowUp(x,y):
    gfx.triangle(10+x, 0+y, 0+x, 10+y, 20+x, 10+y, 1)

def arrowDown(x,y):
    gfx.triangle(0+x, 0+y, 20+x, 0+y, 10+x, 10+y, 1)

def noArrow(x,y):
    gfx.rect(0+x, 4+y, 20, 5, 1)

def readingScreen():
    global prevTemp, prevHumi
    sensor.measure()                                             # READ DATA
    oled.fill(0)                                                 # CLEAR SCREEN
    oled.text("Weather Station",2,4)                             # TITLE DISPLAY
    oled.rect(0,0,127,15,1)
    oled.rect(0,16,127,48,1)                                     # BOX READINGS
    oled.hline(0,39,127,1)                                       # BOX READINGS
    oled.vline(100,16,48,1)                                      # BOX MOVEMENT
    newTemp = sensor.temperature()                               # READ TEMP
    newHumi = sensor.humidity()                                  # READ HUMIDITY
    write20.text("TEMP:{}*C".format(newTemp),3,18)               # DISPLAY TEMP
    write20.text("HUMI:{}%".format(newHumi),3,41)                # DISPLAY HUMIDITY

    if newTemp > prevTemp:                                       # TEMPERATURE GOING UP
        arrowUp(103,22)
    elif newTemp < prevTemp:                                     # TEMPERATURE GOING DOWN
        arrowDown(103,22)
    else:                                                        # STATIC TEMPERATURE
        noArrow(103,22)
    
    if newHumi > prevHumi:                                       # HUMIDITY GOING UP
        arrowUp(103,44)
    elif newHumi < prevHumi:                                     # HUMIDITY GOING DOWN
        arrowDown(103,44)
    else:                                                        # STATIC HUMIDITY
        noArrow(103,44)
    prevTemp = newTemp                                           # STORE NEW TEMP
    prevHumi = newHumi                                           # STORE NEW HUMIDITY
    oled.show()                                                  # DISPLAY THE SCREEN
    time.sleep(2)
    
tim = Timer(period=1000, mode=Timer.PERIODIC, callback=lambda t:led.toggle()) # blinky to show I'm alive!
reset.irq(trigger=Pin.IRQ_RISING, handler=resetcallback)                      # RESET SYSTEM

while True:
    readingScreen()
