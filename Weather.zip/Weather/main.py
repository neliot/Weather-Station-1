############################################
# TITLE  # WEATHER APP
# AUTHOR # DR NEIL ELIOT
# DATE   # 08/01/2023
############################################
# NOTES
###################################################################################
# BEWARE ONLY USE THE INTERNAL DHT11 LIBRARY OR IT FREEZES
###################################################################################
# NE - 22/02/2023
# REMOVED BUZZER
###################################################################################

from machine import Pin
import ssd1306
from oled import Write, GFX, SSD1306_I2C
from oled.fonts import ubuntu_mono_12, ubuntu_mono_15, ubuntu_mono_20
from dht import DHT11
import time

#buzzer = Pin(6,Pin.OUT)
reset = Pin(15,Pin.OUT)
sensor = DHT11(Pin(7))
led = Pin(25,Pin.OUT)
i2c = machine.I2C(0,sda=Pin(16), scl=Pin(17), freq=400000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)
gfx = GFX(128, 64, oled.pixel)
write12 = Write(oled, ubuntu_mono_12)
write15 = Write(oled, ubuntu_mono_15)
write20 = Write(oled, ubuntu_mono_20)

prevTemp = 0
prevHumi = 0

#def buzz():
#    buzzer.value(1)
#    time.sleep(0.05)
#    buzzer.value(0)

def arrowUp(x,y):
    gfx.triangle(10+x, 0+y, 0+x, 10+y, 20+x, 10+y, 1)

def arrowDown(x,y):
    gfx.triangle(0+x, 0+y, 20+x, 0+y, 10+x, 10+y, 1)

def noArrow(x,y):
    gfx.rect(0+x, 4+y, 20, 5, 1)

while True:
    led.toggle()
    sensor.measure()                                             # READ DATA
    oled.fill(0)                                                 # CLEAR SCREEN
    oled.text("Weather Station",2,4)                             # TITLE DISPLAY
    oled.rect(0,0,127,15,1)
    oled.rect(0,16,127,48,1)                                     # BOX READINGS
    oled.hline(0,39,127,1)                                       # BOX READINGS
    oled.vline(100,16,48,1)                                      # BOX MOVEMENT
    newTemp = sensor.temperature()                               # READ TEMP
    newHumi = sensor.humidity()                                  # READ HUMIDITY
    write20.text("TEMP:{}*C".format(newTemp),3,18)               # DISPLAY TEMP
    write20.text("HUMI:{}%".format(newHumi),3,41)                # DISPLAY HUMIDITY

    if newTemp > prevTemp:                                       # TEMPERATURE GOING UP
        arrowUp(103,22)
#        buzz()
    elif newTemp < prevTemp:                                     # TEMPERATURE GOING DOWN
        arrowDown(103,22)
#        buzz()
    else:                                                        # STATIC TEMPERATURE
        noArrow(103,22)
    
    if newHumi > prevHumi:                                       # HUMIDITY GOING UP
        arrowUp(103,44)
#        buzz()
    elif newHumi < prevHumi:                                     # HUMIDITY GOING DOWN
        arrowDown(103,44)
#        buzz()
    else:                                                        # STATIC HUMIDITY
        noArrow(103,44)

    prevTemp = newTemp                                           # STORE NEW TEMP
    prevHumi = newHumi                                           # STORE NEW HUMIDITY

    if reset.value():                                            # RESET PICO
        machine.reset()
        
    oled.show()                                                  # DISPLAY THE SCREEN
    time.sleep(2)                                                # PAUSE 2 SECONDS
