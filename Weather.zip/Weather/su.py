from ssd1306 import SSD1306_I2C
import framebuf
import time

i2c = machine.I2C(0,sda=machine.Pin(16), scl=machine.Pin(17), freq=400000)
oled = SSD1306_I2C(128, 64, i2c)
oled.poweroff()
oled.poweron()

def splash(file):
    with open(file, 'rb') as f:
        f.readline() # Magic number
        f.readline() # Creator comment
        f.readline() # Dimensions
        data = bytearray(f.read())
    fbuf = framebuf.FrameBuffer(data, 128, 64, framebuf.MONO_HLSB)
    oled.blit(fbuf, 0, 0)
    oled.show()

splash('su.pbm')
time.sleep(2)
splash('fot.pbm')
time.sleep(2)
splash('socs.pbm')
time.sleep(3)

